package com.danzi.pac.domain;

import java.util.Date;

public class HrResource {
    private String username;

    private Integer id;

    private String newpassword;

    private String oldpassword;

    private String user;

    private Date createTime;

    private Date loginTime;

    private Date outTime;

    private Integer maxlogin;

    private Integer online;

    private String loginip;

    private Integer userstatus;

    private String phone;

    private String email;

    private String hrresourcecol1;

    private String hrresourcecol2;

    private String hrresourcecol3;

    private String hrresourcecol4;

    private String hrresourcecol5;

    private String hrresourcecol6;

    private String hrresourcecol7;

    private String createTimeStr;

    private String loginTimeStr;

    private String outTimeStr;

    private String msg;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNewpassword() {
        return newpassword;
    }

    public void setNewpassword(String newpassword) {
        this.newpassword = newpassword == null ? null : newpassword.trim();
    }

    public String getOldpassword() {
        return oldpassword;
    }

    public void setOldpassword(String oldpassword) {
        this.oldpassword = oldpassword == null ? null : oldpassword.trim();
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user == null ? null : user.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(Date loginTime) {
        this.loginTime = loginTime;
    }

    public Date getOutTime() {
        return outTime;
    }

    public void setOutTime(Date outTime) {
        this.outTime = outTime;
    }

    public Integer getMaxlogin() {
        return maxlogin;
    }

    public void setMaxlogin(Integer maxlogin) {
        this.maxlogin = maxlogin;
    }

    public Integer getOnline() {
        return online;
    }

    public void setOnline(Integer online) {
        this.online = online;
    }

    public String getLoginip() {
        return loginip;
    }

    public void setLoginip(String loginip) {
        this.loginip = loginip == null ? null : loginip.trim();
    }

    public Integer getUserstatus() {
        return userstatus;
    }

    public void setUserstatus(Integer userstatus) {
        this.userstatus = userstatus;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getHrresourcecol1() {
        return hrresourcecol1;
    }

    public void setHrresourcecol1(String hrresourcecol1) {
        this.hrresourcecol1 = hrresourcecol1 == null ? null : hrresourcecol1.trim();
    }

    public String getHrresourcecol2() {
        return hrresourcecol2;
    }

    public void setHrresourcecol2(String hrresourcecol2) {
        this.hrresourcecol2 = hrresourcecol2 == null ? null : hrresourcecol2.trim();
    }

    public String getHrresourcecol3() {
        return hrresourcecol3;
    }

    public void setHrresourcecol3(String hrresourcecol3) {
        this.hrresourcecol3 = hrresourcecol3 == null ? null : hrresourcecol3.trim();
    }

    public String getHrresourcecol4() {
        return hrresourcecol4;
    }

    public void setHrresourcecol4(String hrresourcecol4) {
        this.hrresourcecol4 = hrresourcecol4 == null ? null : hrresourcecol4.trim();
    }

    public String getHrresourcecol5() {
        return hrresourcecol5;
    }

    public void setHrresourcecol5(String hrresourcecol5) {
        this.hrresourcecol5 = hrresourcecol5 == null ? null : hrresourcecol5.trim();
    }

    public String getHrresourcecol6() {
        return hrresourcecol6;
    }

    public void setHrresourcecol6(String hrresourcecol6) {
        this.hrresourcecol6 = hrresourcecol6 == null ? null : hrresourcecol6.trim();
    }

    public String getHrresourcecol7() {
        return hrresourcecol7;
    }

    public void setHrresourcecol7(String hrresourcecol7) {
        this.hrresourcecol7 = hrresourcecol7 == null ? null : hrresourcecol7.trim();
    }

    public String getCreateTimeStr() {
        return createTimeStr;
    }

    public void setCreateTimeStr(String createTimeStr) {
        this.createTimeStr = createTimeStr == null ? null : createTimeStr.trim();
    }

    public String getLoginTimeStr() {
        return loginTimeStr;
    }

    public void setLoginTimeStr(String loginTimeStr) {
        this.loginTimeStr = loginTimeStr == null ? null : loginTimeStr.trim();
    }

    public String getOutTimeStr() {
        return outTimeStr;
    }

    public void setOutTimeStr(String outTimeStr) {
        this.outTimeStr = outTimeStr == null ? null : outTimeStr.trim();
    }

    @Override
    public String toString() {
        return "HrResource{" +
                "username='" + username + '\'' +
                ", id=" + id +
                ", newpassword='" + newpassword + '\'' +
                ", oldpassword='" + oldpassword + '\'' +
                ", user='" + user + '\'' +
                ", createTime=" + createTime +
                ", loginTime=" + loginTime +
                ", outTime=" + outTime +
                ", maxlogin=" + maxlogin +
                ", online=" + online +
                ", loginip='" + loginip + '\'' +
                ", userstatus=" + userstatus +
                ", phone='" + phone + '\'' +
                ", email='" + email + '\'' +
                ", hrresourcecol1='" + hrresourcecol1 + '\'' +
                ", hrresourcecol2='" + hrresourcecol2 + '\'' +
                ", hrresourcecol3='" + hrresourcecol3 + '\'' +
                ", hrresourcecol4='" + hrresourcecol4 + '\'' +
                ", hrresourcecol5='" + hrresourcecol5 + '\'' +
                ", hrresourcecol6='" + hrresourcecol6 + '\'' +
                ", hrresourcecol7='" + hrresourcecol7 + '\'' +
                ", createTimeStr='" + createTimeStr + '\'' +
                ", loginTimeStr='" + loginTimeStr + '\'' +
                ", outTimeStr='" + outTimeStr + '\'' +
                ", msg='" + msg + '\'' +
                '}';
    }
}