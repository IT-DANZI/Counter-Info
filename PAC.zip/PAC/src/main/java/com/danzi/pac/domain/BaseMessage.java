package com.danzi.pac.domain;

/**
 * Describe ：
 * <p>
 * Author   ：Lily
 * <p>
 * Date     ：2017/8/24.
 */
public class BaseMessage<T> {
}
