package com.danzi.pac.domain;

import java.util.Date;
import java.util.List;

public class ProRecordMain {
    private Integer id;

    private String owerid;

    private String productcode;

    private String productname;

    private String packagcoding;

    private String packagpro;

    private String oldcoding;

    private Date filingTime;

    private Date updateTime;

    private Date createTime;

    private String user;

    private Integer delstatus;

    private String updateuser;

    private String prorecordcol1;

    private String prorecordcol2;

    private String prorecordcol3;

    private String prorecordcol4;

    private String prorecordcol5;

    private String prorecordcol6;

    private String filingTimeStr;

    private String updateTimeStr;

    private String createTimeStr;

    @Override
    public String toString() {
        return "ProRecordMain{" +
                "id=" + id +
                ", owerid='" + owerid + '\'' +
                ", productcode='" + productcode + '\'' +
                ", productname='" + productname + '\'' +
                ", packagcoding='" + packagcoding + '\'' +
                ", packagpro='" + packagpro + '\'' +
                ", oldcoding='" + oldcoding + '\'' +
                ", filingTime=" + filingTime +
                ", updateTime=" + updateTime +
                ", createTime=" + createTime +
                ", user='" + user + '\'' +
                ", delstatus=" + delstatus +
                ", updateuser='" + updateuser + '\'' +
                ", prorecordcol1='" + prorecordcol1 + '\'' +
                ", prorecordcol2='" + prorecordcol2 + '\'' +
                ", prorecordcol3='" + prorecordcol3 + '\'' +
                ", prorecordcol4='" + prorecordcol4 + '\'' +
                ", prorecordcol5='" + prorecordcol5 + '\'' +
                ", prorecordcol6='" + prorecordcol6 + '\'' +
                ", filingTimeStr='" + filingTimeStr + '\'' +
                ", updateTimeStr='" + updateTimeStr + '\'' +
                ", createTimeStr='" + createTimeStr + '\'' +
                ", groundInfoMessageList=" + groundInfoMessageList +
                ", alterInfoMessagesList=" + alterInfoMessagesList +
                ", sysMessageList=" + sysMessageList +
                '}';
    }

    public List<GroundInfoMessage> getGroundInfoMessageList() {
        return groundInfoMessageList;
    }

    public void setGroundInfoMessageList(List<GroundInfoMessage> groundInfoMessageList) {
        this.groundInfoMessageList = groundInfoMessageList;
    }

    public List<AlterInfoMessage> getAlterInfoMessagesList() {
        return alterInfoMessagesList;
    }

    public void setAlterInfoMessagesList(List<AlterInfoMessage> alterInfoMessagesList) {
        this.alterInfoMessagesList = alterInfoMessagesList;
    }

    public List<SysMessage> getSysMessageList() {
        return sysMessageList;
    }

    public void setSysMessageList(List<SysMessage> sysMessageList) {
        this.sysMessageList = sysMessageList;
    }

    private List<GroundInfoMessage> groundInfoMessageList;

    private List<AlterInfoMessage> alterInfoMessagesList;

    private List<SysMessage> sysMessageList;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOwerid() {
        return owerid;
    }

    public void setOwerid(String owerid) {
        this.owerid = owerid == null ? null : owerid.trim();
    }

    public String getProductcode() {
        return productcode;
    }

    public void setProductcode(String productcode) {
        this.productcode = productcode == null ? null : productcode.trim();
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname == null ? null : productname.trim();
    }

    public String getPackagcoding() {
        return packagcoding;
    }

    public void setPackagcoding(String packagcoding) {
        this.packagcoding = packagcoding == null ? null : packagcoding.trim();
    }

    public String getPackagpro() {
        return packagpro;
    }

    public void setPackagpro(String packagpro) {
        this.packagpro = packagpro == null ? null : packagpro.trim();
    }

    public String getOldcoding() {
        return oldcoding;
    }

    public void setOldcoding(String oldcoding) {
        this.oldcoding = oldcoding == null ? null : oldcoding.trim();
    }

    public Date getFilingTime() {
        return filingTime;
    }

    public void setFilingTime(Date filingTime) {
        this.filingTime = filingTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user == null ? null : user.trim();
    }

    public Integer getDelstatus() {
        return delstatus;
    }

    public void setDelstatus(Integer delstatus) {
        this.delstatus = delstatus;
    }

    public String getUpdateuser() {
        return updateuser;
    }

    public void setUpdateuser(String updateuser) {
        this.updateuser = updateuser == null ? null : updateuser.trim();
    }

    public String getProrecordcol1() {
        return prorecordcol1;
    }

    public void setProrecordcol1(String prorecordcol1) {
        this.prorecordcol1 = prorecordcol1 == null ? null : prorecordcol1.trim();
    }

    public String getProrecordcol2() {
        return prorecordcol2;
    }

    public void setProrecordcol2(String prorecordcol2) {
        this.prorecordcol2 = prorecordcol2 == null ? null : prorecordcol2.trim();
    }

    public String getProrecordcol3() {
        return prorecordcol3;
    }

    public void setProrecordcol3(String prorecordcol3) {
        this.prorecordcol3 = prorecordcol3 == null ? null : prorecordcol3.trim();
    }

    public String getProrecordcol4() {
        return prorecordcol4;
    }

    public void setProrecordcol4(String prorecordcol4) {
        this.prorecordcol4 = prorecordcol4 == null ? null : prorecordcol4.trim();
    }

    public String getProrecordcol5() {
        return prorecordcol5;
    }

    public void setProrecordcol5(String prorecordcol5) {
        this.prorecordcol5 = prorecordcol5 == null ? null : prorecordcol5.trim();
    }

    public String getProrecordcol6() {
        return prorecordcol6;
    }

    public void setProrecordcol6(String prorecordcol6) {
        this.prorecordcol6 = prorecordcol6 == null ? null : prorecordcol6.trim();
    }

    public String getFilingTimeStr() {
        return filingTimeStr;
    }

    public void setFilingTimeStr(String filingTimeStr) {
        this.filingTimeStr = filingTimeStr == null ? null : filingTimeStr.trim();
    }

    public String getUpdateTimeStr() {
        return updateTimeStr;
    }

    public void setUpdateTimeStr(String updateTimeStr) {
        this.updateTimeStr = updateTimeStr == null ? null : updateTimeStr.trim();
    }

    public String getCreateTimeStr() {
        return createTimeStr;
    }

    public void setCreateTimeStr(String createTimeStr) {
        this.createTimeStr = createTimeStr == null ? null : createTimeStr.trim();
    }
}