package com.danzi.pac.domain;

/**
 * Describe ：
 * <p>
 * Author   ：Lily
 * <p>
 * Date     ：2017/8/14.
 */
public class Utils {
    private String tablename;
    private String tablfeild;

    public String getTablfeild() {
        return tablfeild;
    }

    public void setTablfeild(String tablfeild) {
        this.tablfeild = tablfeild;
    }

    public String getTablename() {
        return tablename;

    }

    public void setTablename(String tablename) {
        this.tablename = tablename;
    }




}
