package com.danzi.pac.utils;

/**
 * Describe ：
 * <p>
 * Author   ：Lily
 * <p>
 * Date     ：2017/8/13.
 */
public class Mess {
    public static String MES_SUCCCESS = CommonUtils.showTime()+"成功！";
    public static String MES_ERROR_ADD = CommonUtils.showTime()+"添加用户信息失败！请检查用户信息！用户或者已经存在！";
    public static String MES_ERROR = CommonUtils.showTime()+"插入失败！";
}
