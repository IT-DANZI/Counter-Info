package com.danzi.pac.utils;

/**
 * Describe ：
 * <p>
 * Author   ：Lily
 * <p>
 * Date     ：2017/9/12.
 */
public class URL {
    public static String MANAGER_INFO="manager/manager_info";//管理员信息页面
    public static String PRODUCT_RECORD="manager/productsRecode_info";//产品备案信息页面
    public static String PRODUCT_RECORD_EDIT="manager/productsRecode_edit";//产品备案信息编辑页面
}
